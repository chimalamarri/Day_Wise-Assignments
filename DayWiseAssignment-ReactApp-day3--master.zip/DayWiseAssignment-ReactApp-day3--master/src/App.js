import logo from './logo.svg';
import './App.css';
// import Todos from './components/Hooks/Todos';
// import SubmitForm from './components/Forms/SubmitForm';
// import LoginForm from './components/Forms/LoginForm';
// import ShoppingCart from './components/Forms/ShoppingCart';
// import FetchAPI from './components/Hooks/FetchAPI';
import SearchQuery from './components/Hooks/SearchQuery';
import FetchAPI from './components/Hooks/FetchAPI';
import Todos from './components/Hooks/Todos';
import TodoAPI from './components/Hooks/TodoAPI';

function App() {
  return (
    <div className="App">
      {/* <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
       <Todos/>
        <SubmitForm/>
      <FetchAPI/>

      <SearchQuery/>
      <FetchAPI/>
      
      */}

      <TodoAPI/>

      

      

    

     
    </div>
  );
}

export default App;
