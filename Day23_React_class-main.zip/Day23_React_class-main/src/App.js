import React from "react";
import Product from "./components/Product";


function App() {
  return (
    <div>
      <Product />
    </div>
  );
}

export default App;
