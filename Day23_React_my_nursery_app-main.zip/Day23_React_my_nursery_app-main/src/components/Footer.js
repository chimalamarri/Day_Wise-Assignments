import React from "react";
import "./Footer.css";

const Footer = () => {
  return (
    <div className="footer">
      © 2025 My Nursery App | All Rights Reserved.
    </div>
  );
};

export default Footer;
