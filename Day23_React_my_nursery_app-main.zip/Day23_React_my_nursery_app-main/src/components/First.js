import React from 'react';
import "./First.css";

const message= "Creating the Nursery Page";
const flowers = ['Rose', 'Lily', 'Tulip', 'Sunflower', 'Jasmine'];

const First = () => {
  return (
    <div className="container">
        <h1 id="h1">{message}</h1>
        <p>A welcome message to the nursery landing page.</p>

        <select>
            <option value="Chennai">Chennai</option>
            <option value="Bangalore">Bangalore</option>
            <option value="Mumbai">Mumbai</option>
            <option selected value="Delhi">Delhi</option>
        </select>

        <ul>
          {flowers.map((flower, index) => (
            <li key="{index}">{flower}</li>
          ))}
        </ul>
    </div>
  )
}

export default First;
