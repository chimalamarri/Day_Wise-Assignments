package com.connectly.userprofileservice.service;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class UserProfileService {

    @Autowired
    private RestTemplate restTemplate;

    private static final String CB_NAME = "externalService";

    @CircuitBreaker(name = CB_NAME, fallbackMethod = "fallbackMethod")
    public String getUserProfile(String userId) {
        String url = "http://localhost:8081/api/db/users/" + userId;
        String response = restTemplate.getForObject(url, String.class);
        return "Success: " + response;
    }

    public String fallbackMethod(String userId, Throwable t) {
        return "Fallback: User Profile Service is currently unavailable for user ID " + userId + ". " + t.getMessage();
    }
}
