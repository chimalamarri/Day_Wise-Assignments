
import './App.css';
import CaseStudy1 from './cs1';

function App() {
  return (
    <div className="App">
      <CaseStudy1 />
    </div>
  );
}

export default App;
