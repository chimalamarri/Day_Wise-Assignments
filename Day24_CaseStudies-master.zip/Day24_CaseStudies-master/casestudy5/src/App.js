import './App.css';
import TodoTracker from './cs5';
function App() {
  return (
    <div className="App">
      <TodoTracker />
    </div>
  );
}

export default App;
