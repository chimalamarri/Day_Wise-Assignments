
import './App.css';
import CS4 from './cs4';

function App() {
  return (
    <div className="App">
      <CS4 />
    </div>
  );
}

export default App;
