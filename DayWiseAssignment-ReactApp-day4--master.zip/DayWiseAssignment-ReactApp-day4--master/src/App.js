import logo from './logo.svg';
import './App.css';
import Multiple from './components/Multiple';
import FormValidate from './components/FormValidate';
import FeedbackForm from './components/FeedbackForm';
import UnController from './components/UnController';

function App() {
  return (
    <div className="App">
     {/* <Multiple/> 
     <FormValidate/>
<FeedbackForm/>

     */}

<UnController/>
     
    </div>
  );
}

export default App;
