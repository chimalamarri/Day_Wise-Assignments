import React from 'react'

const display = event=>alert(event.target.id)

const Event= () => {
  return (
    <div>
        <h1>Adding Events to Elements</h1>
        <button id="myId" onClick={display}>Click here</button>

    </div>
  )
}

export default Event;