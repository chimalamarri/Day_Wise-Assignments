package com.ecommerce.order_service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ecommerce.order_service.client.PaymentClient;
import com.ecommerce.order_service.client.ProductClient;
import com.ecommerce.order_service.model.Order;
import com.ecommerce.order_service.model.Payment;
import com.ecommerce.order_service.model.Product;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private ProductClient productClient;

    @Autowired
    private PaymentClient paymentClient;

    @PostMapping
    public Order placeOrder(@RequestBody Order order) {
        Product product = productClient.getProduct(order.getProductId());
        if (product.getStock() < order.getQuantity()) {
            throw new RuntimeException("Insufficient stock");
        }

        order.setTotalAmount(product.getPrice() * order.getQuantity());
        order.setStatus("PENDING_PAYMENT");

        Payment payment = paymentClient.processPayment(
                new Payment(order.getOrderId(), order.getTotalAmount(), "Credit Card", "")
        );

        if ("SUCCESS".equals(payment.getStatus())) {
            order.setStatus("CONFIRMED");
            productClient.reduceStock(order.getProductId(), order.getQuantity());
        }

        return order;
    }
}
