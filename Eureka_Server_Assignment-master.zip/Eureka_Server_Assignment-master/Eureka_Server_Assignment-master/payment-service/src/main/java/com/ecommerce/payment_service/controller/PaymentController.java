package com.ecommerce.payment_service.controller;

import com.ecommerce.payment_service.model.Payment;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payments")
public class PaymentController {

    @PostMapping
    public Payment processPayment(@RequestBody Payment payment) {
        payment.setStatus("SUCCESS"); // Simulate payment success
        return payment;
    }
}
